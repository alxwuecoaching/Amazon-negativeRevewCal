# Amazon Review 評分追蹤計算器

免費靜態網頁工具。學員輸入 1–5 星評價各有幾多個，便可即時計算算術平均分、目標分數（預設 4.8）以及最少需要再增加幾多個五星評價。

## 發布到 GitHub Pages

1. 在 Repository `alxwuecoaching/Amazon-negativeRevewCal` 按 **Add file → Upload files**，上傳 `index.html` 及 `README.md` 到根目錄，然後 Commit。
2. 到 **Settings → Pages**，在 **Build and deployment** 選 **Deploy from a branch**。
3. Branch 選 **main**，Folder 選 **/(root)**，按 Save。
4. 等候部署完成，網址通常是 `https://alxwuecoaching.github.io/Amazon-negativeRevewCal/`。

可以直接用瀏覽器開啟 `index.html` 預覽，毋須 Node.js、資料庫或收費伺服器。

## 注意

計算器採用算術平均。Amazon 實際星級評分可能受其他因素影響，結果不保證等於 Amazon 前台顯示。工具僅供規劃和教學，不鼓勵操控評價；所有評價必須真實、自願及符合平台政策。
